# Autocratic Attendance – Android project

Company: Autocratic Solution Pvt. Ltd.

## Demo login
- Admin: `admin` / `admin123`
- Employee: `emp001` / `1234`

## Build APK (Windows / Android Studio)
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Open this `AutocraticAttendance` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to Android phone and install. Allow installation from that source when Android asks.

## Important limitations of this starter version
- This is a local demo: records and employee accounts are stored on the device only. It is not yet a shared multi-phone company system.
- Admin and employee demo credentials are not secure production authentication.
- GPS uses the phone's last known location. For reliable live location, enable Location/GPS and grant permissions.
- Camera intent returns a preview-sized selfie image. Production deployment should use CameraX, secure photo upload, server-side timestamp/location validation, and role-based authentication.
- CSV export is provided; Excel can open the CSV file.
- Leave requests are stored locally; approval workflow and cloud sync need a backend (e.g. Firebase).
- Before company-wide use, change demo passwords, add a secure backend, privacy notice, retention policy and test on target phones.

## हिंदी में
यह शुरुआती Android प्रोजेक्ट है। इसमें कर्मचारी लॉगिन, GPS के साथ selfie check-in/check-out, रिकॉर्ड देखना, admin panel, नया कर्मचारी जोड़ना और CSV export शामिल हैं। अभी डेटा केवल उसी मोबाइल में सेव होता है; सभी कर्मचारियों के मोबाइल पर एक साझा सिस्टम चलाने के लिए Firebase/backend जोड़ना आवश्यक है।
