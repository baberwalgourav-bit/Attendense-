package com.autocratic.attendance;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.location.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import com.google.android.gms.location.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private final int REQ_PERMS=20, REQ_CAMERA=21;
    private android.content.SharedPreferences prefs;
    private LinearLayout root;
    private String user="", role="";
    private boolean hindi=false, pendingIn=false;
    private FusedLocationProviderClient fused;
    private double lat=0, lon=0;
    private Bitmap selfie;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences("attendance_data", MODE_PRIVATE);
        fused=LocationServices.getFusedLocationProviderClient(this);
        loginScreen();
    }
    private TextView text(String s,int size) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(28,45,62)); t.setPadding(4,8,4,8); return t;
    }
    private Button btn(String s, Runnable r) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false);
        b.setOnClickListener(v->r.run()); return b;
    }
    private void setup(String heading) {
        ScrollView sc=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(1);
        root.setPadding(22,22,22,24); root.setBackgroundColor(Color.rgb(245,248,252));
        sc.addView(root); setContentView(sc);
        TextView brand=text("AUTOCRATIC SOLUTION PVT. LTD.",17); brand.setTextColor(Color.rgb(18,59,99)); brand.setTypeface(null,1); root.addView(brand);
        TextView h=text(heading,24); h.setTypeface(null,1); root.addView(h);
    }
    private EditText edit(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); root.addView(e); return e; }
    private void loginScreen() {
        setup("Autocratic Attendance");
        root.addView(text("Office Employee Attendance | कार्यालय उपस्थिति",15));
        EditText id=edit("Employee ID / Admin ID");
        EditText pw=edit("Password");
        pw.setInputType(129);
        root.addView(btn("Login / लॉगिन",()->{
            String a=id.getText().toString().trim(), p=pw.getText().toString();
            if(a.equals("admin") && p.equals("admin123")) { user="Admin"; role="admin"; adminScreen(); }
            else if((a.equals("emp001") && p.equals("1234")) || prefs.getString("pw_"+a,"").equals(p)) {
                user=a; role="employee"; employeeScreen();
            } else toast("Invalid login. Demo: emp001 / 1234 or admin / admin123");
        }));
        root.addView(btn("हिन्दी / English",()->{ hindi=!hindi; loginScreen(); }));
        root.addView(text("Demo login: Employee emp001 / 1234\nAdmin: admin / admin123\n\nDemo data is stored on this device.",13));
    }
    private void employeeScreen() {
        setup((hindi?"कर्मचारी पैनल":"Employee Panel")+" – "+user);
        root.addView(text(hindi?"आज की उपस्थिति":"Today's attendance",18));
        root.addView(btn(hindi?"चेक-इन + सेल्फी":"Check In + Selfie",()->{ pendingIn=true; capture(); }));
        root.addView(btn(hindi?"चेक-आउट + सेल्फी":"Check Out + Selfie",()->{ pendingIn=false; capture(); }));
        root.addView(btn(hindi?"मेरी उपस्थिति":"My Attendance",()->showRecords(user)));
        root.addView(btn(hindi?"छुट्टी का अनुरोध":"Request Leave",()->leaveRequest()));
        root.addView(btn("हिन्दी / English",()->{hindi=!hindi; employeeScreen();}));
        root.addView(btn(hindi?"लॉग आउट":"Logout",()->loginScreen()));
    }
    private void capture() {
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED ||
           ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_PERMS); return;
        }
        getLocationAndCamera();
    }
    private void getLocationAndCamera() {
        try {
            fused.getLastLocation().addOnSuccessListener(this, loc->{
                if(loc!=null){lat=loc.getLatitude();lon=loc.getLongitude();}
                else {lat=0;lon=0;}
                Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(i.resolveActivity(getPackageManager())!=null) startActivityForResult(i,REQ_CAMERA);
                else saveAttendance();
            });
        } catch(Exception e) { toast("Location unavailable. Enable GPS and try again."); }
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if(r==REQ_PERMS) {
            boolean ok=ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
            if(ok) getLocationAndCamera(); else toast("Location permission is required for attendance.");
        }
    }
    @Override protected void onActivityResult(int r,int c,Intent data) {
        super.onActivityResult(r,c,data);
        if(r==REQ_CAMERA && c==RESULT_OK && data!=null && data.getExtras()!=null) {
            Object obj=data.getExtras().get("data"); if(obj instanceof Bitmap) selfie=(Bitmap)obj;
            saveAttendance();
        } else if(r==REQ_CAMERA) toast("Selfie cancelled. Attendance not saved.");
    }
    private void saveAttendance() {
        String now=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(new Date());
        String type=pendingIn?"CHECK_IN":"CHECK_OUT";
        String photo="";
        try {
            if(selfie!=null) {
                File f=new File(getFilesDir(),"selfie_"+System.currentTimeMillis()+".jpg");
                FileOutputStream out=new FileOutputStream(f); selfie.compress(Bitmap.CompressFormat.JPEG,80,out); out.close(); photo=f.getName();
            }
        } catch(Exception ignored) {}
        String row=user+"|"+type+"|"+now+"|"+lat+","+lon+"|"+photo;
        String old=prefs.getString("records","");
        prefs.edit().putString("records",old+row+"\n").apply();
        selfie=null;
        toast((pendingIn?"Check-in":"Check-out")+" saved with GPS & selfie");
        employeeScreen();
    }
    private void adminScreen() {
        setup(hindi?"एडमिन डैशबोर्ड":"Admin Dashboard");
        root.addView(text("Company: Autocratic Solution Pvt. Ltd.",15));
        String[] lines=prefs.getString("records","").split("\n");
        int count=0; for(String s:lines) if(!s.trim().isEmpty()) count++;
        root.addView(text("Total attendance entries: "+count,18));
        root.addView(btn("View All Attendance / सभी उपस्थिति",()->showRecords("")));
        root.addView(btn("Add Employee / कर्मचारी जोड़ें",()->addEmployee()));
        root.addView(btn("Export CSV / Excel",()->exportCsv()));
        root.addView(btn("Language: हिन्दी / English",()->{hindi=!hindi;adminScreen();}));
        root.addView(btn("Logout",()->loginScreen()));
        root.addView(text("Admin demo credentials: admin / admin123",13));
    }
    private void showRecords(String filter) {
        setup(hindi?"उपस्थिति रिकॉर्ड":"Attendance Records");
        String all=prefs.getString("records","");
        TextView list=text("",14);
        StringBuilder sb=new StringBuilder();
        String[] rows=all.split("\n");
        for(int i=rows.length-1;i>=0;i--) {
            String s=rows[i]; if(!s.trim().isEmpty() && (filter.isEmpty() || s.startsWith(filter+"|"))) sb.append(s.replace("|","   •   ")).append("\n\n");
        }
        list.setText(sb.length()==0?"No records yet":sb.toString()); root.addView(list);
        root.addView(btn("Back",()->{if(role.equals("admin"))adminScreen();else employeeScreen();}));
    }
    private void addEmployee() {
        EditText id=new EditText(this); id.setHint("New employee ID"); EditText pw=new EditText(this); pw.setHint("Temporary password");
        LinearLayout box=new LinearLayout(this); box.setOrientation(1); box.addView(id); box.addView(pw);
        new AlertDialog.Builder(this).setTitle("Add Employee").setView(box)
        .setPositiveButton("Save",(d,w)->{
            String a=id.getText().toString().trim(), p=pw.getText().toString();
            if(!a.isEmpty()&&!p.isEmpty()){prefs.edit().putString("pw_"+a,p).apply();toast("Employee created: "+a);}
        }).setNegativeButton("Cancel",null).show();
    }
    private void leaveRequest() {
        EditText e=new EditText(this); e.setHint("Leave dates and reason");
        new AlertDialog.Builder(this).setTitle("Leave Request").setView(e)
        .setPositiveButton("Submit",(d,w)->{String old=prefs.getString("leaves","");prefs.edit().putString("leaves",old+user+" | "+e.getText()+"\n").apply();toast("Leave request saved on this device");})
        .setNegativeButton("Cancel",null).show();
    }
    private void exportCsv() {
        StringBuilder csv=new StringBuilder("Employee,Type,DateTime,GPS,SelfieFile\n");
        for(String s:prefs.getString("records","").split("\n")) if(!s.isEmpty()) csv.append(s.replace("|",",")).append("\n");
        try {
            File f=new File(getExternalFilesDir(null),"attendance.csv");
            FileOutputStream o=new FileOutputStream(f);o.write(csv.toString().getBytes("UTF-8"));o.close();
            Intent share=new Intent(Intent.ACTION_SEND);share.setType("text/csv");share.putExtra(Intent.EXTRA_STREAM,Uri.fromFile(f));
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Share attendance CSV"));
        } catch(Exception e){toast("Export failed: "+e.getMessage());}
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}